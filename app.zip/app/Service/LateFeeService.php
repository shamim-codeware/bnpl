<?php

namespace App\Service;


use App\Traits\LateFeeCalculationTrait;

class LateFeeService
{
    use LateFeeCalculationTrait;
}
